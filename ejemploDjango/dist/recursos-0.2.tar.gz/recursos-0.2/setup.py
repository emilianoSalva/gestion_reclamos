from setuptools import setup
setup(
    name="recursos",
    version="0.2",
    description="Paquete de ejemplo django",
    author="Codo a Codo",
    author_email="io.codoacodo@bue.edu.ar",
    url="https://www.buenosaires.gob.ar/educacion/codo-codo",
    packages=['hola_mudo', 'ejemploDjango'],
    scripts=[]
)
