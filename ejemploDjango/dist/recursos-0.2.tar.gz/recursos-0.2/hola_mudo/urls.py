
from django.urls import path
#from hola_mudo import views
from ejemploDjango import views

urlpatterns = [
    path('saludar/',views.saludar),    
]
